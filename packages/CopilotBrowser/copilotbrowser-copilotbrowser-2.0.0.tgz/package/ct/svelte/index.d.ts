/**
 * Copyright (c) Microsoft Corporation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import type { ComponentProps, Component, SvelteComponent } from 'svelte';
import type { TestType, Locator } from '../core/index';

type ComponentSlot = Snippet | string;
type ComponentSlots = Record<string, ComponentSlot> & { default?: ComponentSlot };
type ComponentEvents = Record<string, Function>;

// TODO: Remove after Svelte has removed S4 fallback TypeScript types for `*.svelte` files
type InteropComponent = (new (...args: unknown[]) => SvelteComponent) | Component<any, any, any>;

export interface MountOptions<HooksConfig, Component extends InteropComponent> {
  props?: ComponentProps<Component>;
  slots?: ComponentSlots;
  on?: ComponentEvents;
  hooksConfig?: HooksConfig;
}

export interface MountResult<Component extends InteropComponent> extends Locator {
  unmount(): Promise<void>;
  update(options: {
    props?: Partial<ComponentProps<Component>>;
    on?: Partial<ComponentEvents>;
  }): Promise<void>;
}

export interface ComponentFixtures {
  mount<HooksConfig, Component extends InteropComponent = InteropComponent>(
    component: Component,
    options?: MountOptions<HooksConfig, Component>
  ): Promise<MountResult<Component>>;
}

export const test: TestType<ComponentFixtures>;

export { defineConfig, copilotbrowserTestConfig, expect, devices } from '../core/index';
